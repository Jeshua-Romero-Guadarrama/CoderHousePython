
'''
Paquete "paquete" que contiene módulos para gestionar Clientes.
'''